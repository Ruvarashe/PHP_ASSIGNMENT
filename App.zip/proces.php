<html>
<body>

<?php
$title=$_POST["title"];
$surname=$_POST["surname"];
$name=$_POST["name"];	



$phone=$_POST["phone"];
$citizenship=$_POST["citizenship"];
$agent=$_POST["agent"];
$email=$_POST["email"];
$date=$_POST["date"];
$time=$_POST["time"];

	echo"Title: $title<br>";
	 
	 echo"Surname: $surname<br>";  
	echo"Name: $name<br>";
	
	
	echo"Phone: $phone<br>"; 
	echo"Citizenship: $citizenship<br>"; 
	echo"Agent: $agent<br>"; 
	echo"Email: $email<br>"; 
	echo"Appointment Date: $date<br>"; 
	echo"Appointment Time: $time<br>"; 
?>
<a href="loging.php">Click for more
</body>
</html>