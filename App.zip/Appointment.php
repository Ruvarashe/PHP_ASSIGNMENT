<!doctype html>
<html>
	<head>
		<title>

		</title>
		<!-- Bootstrap -->
    	<link href="css/bootstrap.min.css" rel="stylesheet">
    	<link href="js/bootstrap.min.js" rel="stylesheet">
    	
    	<script type="text/javascript"src"js/jquery.bsvalidate.min.js"></script>
    	<script type="text/javascript"src"js/jquery.bsvalidate.js"></script>
    	<script type="text/javascript"src"js/phone.js"></script>
    	<script type="text/javascript"src"js/jquery.js"></script>
    </head>


	<body>

		<header role="banner" id="main-header">
		<center>
			<div id="logo">
				<img id="logo" src="assets/images.png">
				
			</div>

			<ul class="nav nav-list">
			  <li class="active"><a href="#"><i class="icon-home icon-white"></i> Home</a></li>
			  <li><a href="#"><i class="icon-book"></i> Library</a></li>
			  <li><a href="#"><i class="icon-pencil"></i> Appointments</a></li>
			  <li><a href="#"><i class="i"></i> About</a></li>
			</ul>
		</center>
		<h1>

			<p class="bg-primary">UNDP CLINIC</p>
		</h1>
		<h3>
			<p class="bg-primary">Patients Info</p>
			</h3>
		</header>
		<form  action="proces.php" method="post">
			<div class="form-inline">
				<label class="control-label col-sm-2" for="name">Title:</label>
				<select class="form-control" id="title1" name="title" required="required">
					<option label="Select a title"></option>
					<option value="dr">Dr.</option>
					<option value="esq">Mrs.</option>
					<option value="mr">Mr.</option>
					<option value="ms">Ms.</option>
				</select>
			</div>
			<br>

			<div class="form-group">
			    <label class="control-label col-sm-2" for="surname">Surname:</label>
			    <div class="col-sm-10">
			      <input type="text" class="form-control" id="surname1" name="surname" placeholder="Enter surname" required="required">
			    </div>
			</div>
			<br>
			<br>

			<div class="form-group">
			    <label class="control-label col-sm-2" for="name">Name:</label>
			    <div class="col-sm-10">
			      <input type="text" class="form-control" id="name1" name="name" placeholder="Enter name" required="required">
			    </div>
			</div>
			<br>
			<br>

			

			
			<br>

			<div class="form-group">
			    <label class="control-label col-sm-2" for="Phone Number">Phone Number:</label>
			    <div class="col-sm-10">
			      
			      <label for="phonenum">Phone Number format:( xxxx-xxx-xxx):</label><br>
  					<input id="phonenum" type="text" name="phone" pattern="^\d{4} \d{3} \d{3}$" required >
			    </div>

			</div>
			<br>
			<br>
			<br>



			<div class="form-inline">
				<label class="control-label col-sm-2" for="name">Citizenship Status:</label>
				<select class="form-control" id="c" name="citizenship" required="required">
					<option label="Select your citizenship"></option>
					<option value="Zimbabwean">Zimbabwean</option>
					<option value="Foreigner">Foreigner</option>
					
				</select>
			</div>
			<br>

			<div class="form-inline">
				<label class="control-label col-sm-2" for="name">Choose Your Agent:</label>
				<select class="form-control" id="Agent1" name="agent" required="required">
					<option label="Select your Agent"></option>
					<option value="UNFAO">UNFAO</option>
					<option value="UNESCO">UNESCO</option>
					<option value="WHO">WHO</option>
					<option value="UNIMP">UNIMP</option>
					<option value="UNIDO">UNIDO</option>
					<option value="UNWTO">UNWTO</option>
				</select>
			</div>
			<br>

			
			<br>
			<br>
			<br>
		

		
			
			<div class="form-inline">
					<label for="date"><span class="field-name">Requested Date</span><span class="datepicker-format"> (MM-DD-YY)</span></label>
					<input class="form-control" id="date1" name="date" type="text" data-rule-dateISO="true" required="required" />
				</div>
			</div>
			<br>


			<div class="form-inline">
				<label for="time"><span class="field-name">Requested Time</span> (hh:mm)</label>
				<input class="form-control" id="time1" name="time" type="text" required="required"  />
			</div>
			<br>
			<br>

			<div class="form-group">
			    <label class="control-label col-sm-2" for="email">Email:</label>
			    <div class="col-sm-10">
			       <input type="text" name="email" value="" placeholder="name@email.com" required="required" /><br><br>
			       		
					 <button  type="submit" class="btn btn-primary">Submit
					 <input type="submit" value="Submit" />
					 </button>
					    
			         
			    </div>
			</div>

			<div class="form-group">
			    <div class="col-sm-offset-2 col-sm-10">
			      
			      	<div class="checkbox" 
			       		<label><input type="checkbox"> Remember me</label>
			      	</div>
			    </div>
			</div>
			<br>
			<br>
			
			
		</form>
	</body>
	<section>
		<article>
			<h5>
				<p class="text-centre"><em> Patients are advised to confirm with the receptionist if they can no longer make it for the booked time so that reservations for other patients may be made!</em></p>
		  		
			</h5>
		</article>
		
	</section>
	<br>
	<br>
	<br>
	
</html>