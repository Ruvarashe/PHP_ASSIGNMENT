<!DOCTYPE HTML>
<html>
<head>
	<body>
		<?php
			echo "Welcome " .$_GET['username'];
		?>
	</body>
</head>
</html>